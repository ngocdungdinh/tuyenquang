-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2016 at 05:33 AM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tuyenquang2`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_type` varchar(20) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_parent_id` int(11) NOT NULL DEFAULT '0',
  `act_type_id` tinyint(2) DEFAULT NULL COMMENT 'notifications_type',
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `showon_menu` tinyint(3) NOT NULL,
  `showon_homepage` int(11) NOT NULL,
  `showon_position` int(11) NOT NULL,
  `list_layout` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_layout` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_count` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'on',
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_post`
--

CREATE TABLE IF NOT EXISTS `category_post` (
  `id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `vote` int(11) NOT NULL DEFAULT '0',
  `status` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'on',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE IF NOT EXISTS `conversations` (
  `c_id` int(11) NOT NULL,
  `user_one` int(11) NOT NULL,
  `user_two` int(11) NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `conversation_reply`
--

CREATE TABLE IF NOT EXISTS `conversation_reply` (
  `cr_id` int(11) NOT NULL,
  `reply` text,
  `user_id_fk` int(11) NOT NULL,
  `c_id_fk` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `email_queue`
--

CREATE TABLE IF NOT EXISTS `email_queue` (
  `id` int(11) NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) NOT NULL,
  `to_name` varchar(255) NOT NULL,
  `to_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type_mail` tinytext NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `email_service`
--

CREATE TABLE IF NOT EXISTS `email_service` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0: Không gửi | 1: Đang gửi | 2: Đã gửi',
  `top_handbook` tinyint(1) NOT NULL,
  `top_news` tinyint(1) NOT NULL,
  `lastest_answer` tinyint(1) NOT NULL,
  `sent_number` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `send_date` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `fbf_youtube_access_token`
--

CREATE TABLE IF NOT EXISTS `fbf_youtube_access_token` (
  `id` int(10) unsigned NOT NULL,
  `access_token` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fbf_youtube_access_token`
--

INSERT INTO `fbf_youtube_access_token` (`id`, `access_token`, `created_at`) VALUES
(1, '{"access_token":"ya29.HQAj9ZpmecA3eB8AAABtZqW18b3dnYF9kOSItx9dYyAJfLz-eJi3EEP7UbzE0g","token_type":"Bearer","expires_in":3600,"refresh_token":"1\\/gFoAxLU5_8GHLxWq-TE0CyHutaIHvzl6qFGClp3sFkA","created":1400638548}', '2014-05-20 19:15:48');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '{"users":1,"news.create":1,"admin":1,"user.create":1,"user.edit":1,"user.detele":1,"group.create":1,"group.edit":1,"group.detele":1,"news.edit":1,"news.editpublish":1,"news.delete":1,"news.publish":1,"news.editcategory":1,"news.deletecategory":1,"news.editcomment":1,"pages.create":1,"pages.edit":1,"pages.delete":1,"news.deletecomment":1,"news.createcategory":1,"news.createtag":1,"news.edittag":1,"news.deletetag":1,"handbooks.createpost":1,"handbooks.editpost":1,"handbooks.deletepost":1,"handbooks.createcategory":1,"handbooks.editcategory":1,"handbooks.deletecategory":1,"handbooks.createjob":1,"cart.createproduct":1,"cart.editproduct":1,"cart.deleteproduct":1,"cart.createcategory":1,"cart.editcategory":1,"cart.deletecategory":1,"question.create":1,"question.edit":1,"question.detele":1,"user.doctor":1,"answer.create":1,"answer.edit":1,"answer.detele":1,"user.full":1,"question.full":1,"group.full":1,"pages.full":1,"handbooks.full":1,"news.full":1,"royalty.view":1,"royalty.set":1,"royalty.full":1,"royalty.ownerview":1,"doctor.full":1,"doctor.doctor":1,"settings.config":1,"menus.full":1,"menus.create":1,"menus.edit":1,"menus.delete":1,"statistic.news":1,"statistic.royalty":1,"medias.full":1,"medias.viewall":1,"medias.upload":1,"medias.edit":1,"medias.delete":1,"settings.appearance":1,"category.c1002":1,"category.c1003":1,"category.c1056":1,"category.c1004":1,"category.c1037":1,"category.c1051":1,"category.c1005":1,"category.c1007":1,"category.c1043":1,"category.c1006":1,"category.c1063":1,"category.c1008":1,"category.c1009":1,"category.c1011":1,"category.c1012":1,"category.c1014":1,"category.c1062":1,"category.c1061":1,"category.c1065":1,"category.c1058":1,"category.c79":1,"category.c1001":1,"news.review":1,"news.unpublish":1,"activities.overview":1,"activities.post":1,"news.sort":1,"user.permission":1,"deletecache":1,"category.c1013":1,"category.c1084":1,"viewanalytics":1,"user.online":1,"news.edittopic":1,"news.viewcomment":1,"news.approvecomment":1,"category.c1091":1}', '2013-09-10 23:36:59', '2015-04-17 03:35:23'),
(2, 'Biên tập viên', '{"news.create":1,"admin":1,"question.create":1,"question.edit":1,"question.detele":1,"user.doctor":1,"answer.create":1,"answer.edit":1,"answer.detele":1,"news.edit":1,"news.delete":1,"news.editcomment":1,"news.deletecomment":1,"news.createtag":1,"news.edittag":1,"news.deletetag":1,"medias.upload":1,"medias.edit":1,"medias.delete":1,"handbooks.createpost":1,"handbooks.editpost":1,"handbooks.deletepost":1,"handbooks.createcategory":1,"handbooks.editcategory":1,"handbooks.deletecategory":1,"handbooks.createjob":1,"news.review":1,"news.full":1,"news.sort":1,"news.editpublish":1,"news.publish":1,"news.unpublish":1,"activities.overview":1,"activities.post":1,"royalty.view":1,"medias.viewall":1,"category.c1002":1,"category.c1003":1,"category.c1056":1,"category.c1004":1,"category.c1037":1,"category.c1051":1,"category.c1005":1,"category.c1007":1,"category.c1043":1,"category.c1006":1,"category.c1063":1,"category.c1008":1,"category.c1009":1,"category.c1011":1,"category.c1012":1,"category.c1014":1,"category.c1062":1,"category.c1061":1,"category.c1065":1,"category.c1058":1,"category.c79":1,"category.c1001":1,"user.edit":1,"deletecache":1,"category.c1013":1,"category.c1084":1,"user.online":1,"news.edittopic":1,"news.viewcomment":1,"news.approvecomment":1,"category.c1091":1,"category.c1097":1,"category.c1100":1}', '2013-09-10 23:41:04', '2015-07-05 06:26:52'),
(3, 'Phóng viên', '{"admin":1,"question.create":1,"question.edit":1,"question.detele":1,"news.create":1,"news.delete":1,"news.createtag":1,"news.edittag":1,"news.deletetag":1,"medias.upload":1,"medias.edit":1,"medias.delete":1,"news.editowner":1,"category.c1002":1,"category.c1003":1,"category.c1056":1,"category.c1004":1,"category.c1037":1,"category.c1051":1,"category.c1005":1,"category.c1007":1,"category.c1043":1,"category.c1006":1,"category.c1063":1,"category.c1008":1,"category.c1009":1,"category.c1011":1,"category.c1012":1,"category.c1014":1,"category.c1062":1,"category.c1061":1,"category.c1065":1,"category.c1058":1,"category.c79":1,"category.c1001":1,"activities.post":1,"royalty.ownerview":1,"user.edit":1,"category.c1013":1,"category.c1084":1,"activities.overview":1,"activities.ownpost":1,"news.edit":1,"category.c1091":1,"category.c1097":1,"category.c1100":1}', '2013-09-19 08:36:18', '2015-07-05 06:27:28'),
(4, 'Thành viên', '{"question.create":1,"question.edit":1,"question.detele":1,"medias.upload":1,"medias.edit":1,"medias.delete":1}', '2013-09-19 08:36:52', '2013-11-14 22:45:48'),
(5, 'Cộng tác viên', '{"news.create":1,"news.editowner":1,"news.delete":1,"news.createtag":1,"news.edittag":1,"news.deletetag":1,"medias.upload":1,"medias.edit":1,"medias.delete":1,"user.doctor":1,"answer.create":1,"answer.edit":1,"answer.detele":1,"question.create":1,"question.edit":1,"question.detele":1,"doctor.doctor":1,"category.c1002":1,"category.c1003":1,"category.c1004":1,"category.c1037":1,"category.c1051":1,"category.c1005":1,"category.c1007":1,"category.c1043":1,"category.c1006":1,"category.c1008":1,"category.c1009":1,"category.c1001":1,"activities.post":1,"royalty.ownerview":1,"user.edit":1,"admin":1,"category.c1065":1,"activities.overview":1,"activities.ownpost":1,"category.c1013":1,"category.c1063":1}', '2013-11-13 12:18:39', '2014-09-01 07:19:33'),
(6, 'Thư kí tòa soạn', '{"admin":1,"user.edit":1,"question.full":1,"question.create":1,"question.edit":1,"question.detele":1,"doctor.full":1,"answer.create":1,"answer.edit":1,"answer.detele":1,"news.full":1,"news.create":1,"news.edit":1,"news.editpublish":1,"news.delete":1,"news.publish":1,"news.editcomment":1,"news.deletecomment":1,"news.createtag":1,"news.edittag":1,"news.deletetag":1,"royalty.full":1,"royalty.view":1,"royalty.ownerview":1,"royalty.set":1,"pages.full":1,"pages.create":1,"pages.edit":1,"pages.delete":1,"medias.full":1,"medias.upload":1,"medias.edit":1,"medias.delete":1,"handbooks.full":1,"handbooks.createpost":1,"handbooks.editpost":1,"handbooks.deletepost":1,"handbooks.createcategory":1,"handbooks.editcategory":1,"handbooks.deletecategory":1,"handbooks.createjob":1,"news.sort":1,"news.review":1,"news.unpublish":1,"activities.overview":1,"activities.post":1,"statistic.news":1,"statistic.royalty":1,"medias.viewall":1,"category.c1002":1,"category.c1003":1,"category.c1056":1,"category.c1004":1,"category.c1037":1,"category.c1051":1,"category.c1005":1,"category.c1007":1,"category.c1043":1,"category.c1006":1,"category.c1063":1,"category.c1008":1,"category.c1009":1,"category.c1011":1,"category.c1012":1,"category.c1014":1,"category.c1062":1,"category.c1061":1,"category.c1065":1,"category.c1058":1,"category.c79":1,"category.c1001":1,"user.full":1,"user.create":1,"user.permission":1,"user.detele":1,"deletecache":1,"category.c1013":1,"category.c1084":1,"user.online":1,"news.edittopic":1,"news.viewcomment":1,"news.approvecomment":1,"category.c1091":1,"category.c1097":1,"category.c1100":1}', '2013-12-20 21:21:30', '2015-07-05 06:27:04'),
(7, 'Ban biên tập', '{"admin":1,"deletecache":1,"user.edit":1,"news.full":1,"news.sort":1,"news.create":1,"news.edit":1,"news.editpublish":1,"news.delete":1,"news.review":1,"news.publish":1,"news.unpublish":1,"news.createcategory":1,"news.editcategory":1,"news.deletecategory":1,"news.editcomment":1,"news.deletecomment":1,"news.createtag":1,"news.edittag":1,"news.deletetag":1,"activities.overview":1,"activities.post":1,"royalty.full":1,"royalty.view":1,"royalty.ownerview":1,"royalty.set":1,"statistic.news":1,"statistic.royalty":1,"pages.full":1,"pages.create":1,"pages.edit":1,"pages.delete":1,"medias.full":1,"medias.viewall":1,"medias.upload":1,"medias.edit":1,"medias.delete":1,"category.c1002":1,"category.c1003":1,"category.c1056":1,"category.c1004":1,"category.c1037":1,"category.c1051":1,"category.c1005":1,"category.c1007":1,"category.c1043":1,"category.c1006":1,"category.c1063":1,"category.c1008":1,"category.c1009":1,"category.c1011":1,"category.c1012":1,"category.c1014":1,"category.c1062":1,"category.c1061":1,"category.c1065":1,"category.c1058":1,"category.c79":1,"category.c1001":1,"category.c1013":1,"category.c1084":1,"viewanalytics":1,"user.online":1,"news.edittopic":1,"news.viewcomment":1,"news.approvecomment":1,"category.c1097":1,"category.c1100":1}', '2014-07-22 02:19:06', '2015-07-05 06:27:17');

-- --------------------------------------------------------

--
-- Table structure for table `medias`
--

CREATE TABLE IF NOT EXISTS `medias` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `mpath` varchar(255) NOT NULL,
  `mname` varchar(255) NOT NULL,
  `mtype` varchar(10) NOT NULL DEFAULT 'image',
  `is_upload` tinyint(1) NOT NULL DEFAULT '0',
  `mine_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `position` varchar(15) NOT NULL DEFAULT 'top',
  `status` varchar(5) NOT NULL DEFAULT 'on',
  `showon` tinyint(2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `title`, `position`, `status`, `showon`, `created_at`, `updated_at`) VALUES
(1, 'Menu chính', 'nav', 'on', 0, '2014-02-12 09:35:30', '2014-02-12 10:06:44');

-- --------------------------------------------------------

--
-- Table structure for table `menu_links`
--

CREATE TABLE IF NOT EXISTS `menu_links` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `target` varchar(20) NOT NULL DEFAULT '_self',
  `showon` tinyint(3) NOT NULL,
  `position` tinyint(3) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2012_12_06_225921_migration_cartalyst_sentry_install_users', 1),
('2012_12_06_225929_migration_cartalyst_sentry_install_groups', 1),
('2012_12_06_225945_migration_cartalyst_sentry_install_users_groups_pivot', 1),
('2012_12_06_225988_migration_cartalyst_sentry_install_throttle', 1),
('2013_01_19_011903_create_posts_table', 2),
('2013_01_19_044505_create_comments_table', 2),
('2013_03_23_193214_update_users_table', 2),
('2014_04_09_014401_add_status_to_widgets_table', 3),
('2014_04_09_030934_create_sidebars_table', 4),
('2014_04_09_052341_add_metadata_to_categories_table', 5),
('2014_04_09_163957_create_seos_table', 6),
('2014_04_09_174423_remove_metadata_cat_post_table', 7),
('2014_04_09_175543_create_sidebarrefs_table', 8),
('2014_04_11_155227_create_posts_versions', 9),
('2014_04_15_174233_add_mine_type_to_medias_table', 9),
('2014_01_17_104048_create_youtube_access_token_table', 10),
('2014_05_21_131745_add_subtitle_to_posts_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE IF NOT EXISTS `newsletters` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ntype` varchar(20) NOT NULL DEFAULT 'guest',
  `is_conceive` tinyint(1) NOT NULL DEFAULT '0',
  `is_pregnant` tinyint(1) NOT NULL DEFAULT '0',
  `is_baby` tinyint(1) NOT NULL DEFAULT '0',
  `is_news` tinyint(1) NOT NULL DEFAULT '1',
  `day` int(5) NOT NULL,
  `month` int(5) NOT NULL,
  `year` int(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `recipient` varchar(50) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `noti_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `item_title` varchar(255) NOT NULL,
  `touch` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `people` tinyint(5) NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `notification_type`
--

CREATE TABLE IF NOT EXISTS `notification_type` (
  `id` int(11) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notification_type`
--

INSERT INTO `notification_type` (`id`, `icon`, `name`, `updated_at`, `created_at`) VALUES
(1, 'fa fa-thumbs-o-up', 'thích', '2014-04-03 00:52:02', '0000-00-00 00:00:00'),
(2, 'fa fa-comment-o', 'bình luận', '2014-04-03 00:52:24', '0000-00-00 00:00:00'),
(3, '', 'quan tâm', '2013-11-28 14:34:00', '0000-00-00 00:00:00'),
(4, '', 'sẽ tham gia', '2013-11-28 14:40:32', '0000-00-00 00:00:00'),
(5, '', 'có thể tham gia', '2013-11-28 14:40:32', '0000-00-00 00:00:00'),
(6, '', 'từ chối tham gia', '2013-11-28 14:40:32', '0000-00-00 00:00:00'),
(7, '', 'mời bạn tham gia', '2013-11-28 14:50:49', '0000-00-00 00:00:00'),
(8, 'fa fa-pencil-square-o', 'thêm bài viết mới', '2014-04-03 00:54:51', '0000-00-00 00:00:00'),
(9, 'glyphicon glyphicon-floppy-disk', 'sửa bài viết', '2014-04-03 00:54:39', '0000-00-00 00:00:00'),
(10, 'glyphicon glyphicon-ok-sign', 'xuất bản', '2014-04-03 00:55:07', '0000-00-00 00:00:00'),
(11, 'glyphicon glyphicon-time', 'đợi xét duyệt', '2014-04-03 00:55:33', '0000-00-00 00:00:00'),
(12, 'glyphicon glyphicon-repeat', 'bị trả lại', '2014-04-03 00:56:08', '0000-00-00 00:00:00'),
(13, 'glyphicon glyphicon-trash', 'xóa bài', '2014-04-03 00:56:30', '0000-00-00 00:00:00'),
(14, 'glyphicon glyphicon-import', 'nhận viết bài', '2014-04-03 00:57:18', '0000-00-00 00:00:00'),
(15, 'fa fa-pencil-square', 'nhận duyệt bài', '2014-04-03 00:59:02', '0000-00-00 00:00:00'),
(16, 'fa fa-sign-out', 'gỡ bỏ bài', '2014-04-03 00:59:38', '0000-00-00 00:00:00'),
(17, 'fa fa-comment-o', 'thêm ghi chú', '2014-04-03 02:13:44', '0000-00-00 00:00:00'),
(18, 'glyphicon glyphicon-check', 'đã duyệt bài', '2014-04-06 14:02:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(11) NOT NULL,
  `gid` varchar(100) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(60) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `country` varchar(60) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `type` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `follows` int(11) NOT NULL,
  `search_count` int(11) NOT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_popular` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT 'open',
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_approve_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `category_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relate_posts` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_note` text COLLATE utf8_unicode_ci NOT NULL,
  `media_id` int(11) NOT NULL,
  `status` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'draft',
  `source_news` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` int(11) NOT NULL,
  `source_id` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `has_picture` tinyint(1) NOT NULL DEFAULT '0',
  `has_video` tinyint(1) DEFAULT '0',
  `has_audio` tinyint(1) NOT NULL DEFAULT '0',
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_popular` tinyint(1) NOT NULL DEFAULT '0',
  `showon_homepage` tinyint(1) NOT NULL DEFAULT '0',
  `showon_category` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` int(11) NOT NULL DEFAULT '0',
  `comment_count` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `publish_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `word_count` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_kind` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts_position`
--

CREATE TABLE IF NOT EXISTS `posts_position` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `position` tinyint(3) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'home',
  `publish_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts_versions`
--

CREATE TABLE IF NOT EXISTS `posts_versions` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `version` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_tag`
--

CREATE TABLE IF NOT EXISTS `post_tag` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'default',
  `template` varchar(20) NOT NULL DEFAULT 'default',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `royalties`
--

CREATE TABLE IF NOT EXISTS `royalties` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL DEFAULT 'post' COMMENT 'post, answer...',
  `user_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `royalty` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `received` tinyint(1) NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `seos`
--

CREATE TABLE IF NOT EXISTS `seos` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seoble_id` int(10) unsigned NOT NULL,
  `seoble_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  `value` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `updated_at`, `created_at`) VALUES
(81, 'maintain_info', 'Server hiện thời đang nâng cấp, xin vui lòng quay lại sau!', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(80, 'maintain_mode', 'no', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(79, 'language', 'vi', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(78, 'admin_email', 'ngocdungdinh@gmail.com', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(77, 'site_url', 'http://tuyenquang.dfa.vn', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(76, 'site_info', 'SỞ NGOẠI VỤ TỈNH TUYÊN QUANG | TUYEN QUANG DEPARTMENT OF FOREIGN AFFAIRS', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(82, 'keywords', 'an ninh, xa hoi, thoi su, kinh te, phap luat, phap luat xa hoi, nhat ky 141, cong an nhan dan, chuyen an 141', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(75, 'sitename', 'SỞ NGOẠI VỤ TỈNH TUYÊN QUANG | TUYEN QUANG DEPARTMENT OF FOREIGN AFFAIRS', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(83, 'active_date', '2014-04-12 19:36:10 ', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(84, 'featured_posts', '18', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(85, 'popular_posts', '18', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(86, 'lastest_posts', '18', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(87, 'paging_posts', '20', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(88, 'auto_sortposts', 'yes', '2014-09-01 07:38:40', '0000-00-00 00:00:00'),
(89, 'comment_status', 'on', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(90, 'comment_allow', 'yes', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(91, 'comment_allow_guest', 'yes', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(92, 'comment_perpage', '10', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(93, 'analytic_client_id', '', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(94, 'analytic_service_email', '', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(95, 'analytic_p12_file', '', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(96, 'auto_sortfeatured', 'no', '2016-06-02 02:41:18', '0000-00-00 00:00:00'),
(97, 'auto_sortpopular', 'yes', '2016-06-02 02:41:18', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sidebars`
--

CREATE TABLE IF NOT EXISTS `sidebars` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `position` enum('default','top','bottom','left','right','center') COLLATE utf8_unicode_ci NOT NULL,
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  `status` enum('on','off') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'on',
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sidebars_refs`
--

CREATE TABLE IF NOT EXISTS `sidebars_refs` (
  `id` int(10) unsigned NOT NULL,
  `sidebar_id` int(10) unsigned NOT NULL,
  `seoble_id` int(10) unsigned NOT NULL,
  `seoble_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'tag',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `showon_homepage` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(5) NOT NULL DEFAULT 'on',
  `news_count` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tag_post`
--

CREATE TABLE IF NOT EXISTS `tag_post` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `throttle`
--

CREATE TABLE IF NOT EXISTS `throttle` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `hometown` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `phone_cog` tinyint(1) NOT NULL DEFAULT '1',
  `birth_day` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `birth_month` int(2) NOT NULL,
  `birth_year` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `fb_user` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fb_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fb_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `place_id` int(11) NOT NULL,
  `bio` text COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `activation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_msg` tinyint(1) NOT NULL DEFAULT '0',
  `notifications` tinyint(2) NOT NULL DEFAULT '0',
  `follows` int(11) NOT NULL,
  `is_doctor` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `api_token` varchar(96) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `avatar`, `username`, `gender`, `hometown`, `phone`, `phone_cog`, `birth_day`, `birth_month`, `birth_year`, `fb_user`, `fb_id`, `fb_link`, `location`, `place_id`, `bio`, `password`, `permissions`, `activated`, `activation_code`, `activated_at`, `last_login`, `last_activity`, `persist_code`, `reset_password_code`, `first_name`, `last_name`, `has_msg`, `notifications`, `follows`, `is_doctor`, `created_at`, `updated_at`, `deleted_at`, `website`, `country`, `gravatar`, `api_token`) VALUES
(1, 'dungdn@dungdn.com', '12.04.2014_bb_1397290522.jpg', 'dungdn', 'male', 'Hà Nội', '', 2, '15', 5, '1983', 'binhbeervn', '100004513421116', 'https://www.facebook.com/binhbeervn', 'Hanoi, Vietnam', 61, '', '$2y$10$myAPEphBXklCBRF35eQt/uI12Ytxf89ONZtoDGPaMI3dIlRQsN/NS', '{"admin":1,"user":1,"user.doctor":1}', 1, NULL, NULL, '2016-06-03 03:32:34', '2016-06-03 03:32:46', '$2y$10$Js3nWkrU7Crid5bdohFY9uI4C9mXTAKaY1QgaUeyQKRDmuH0.ZMWq', NULL, 'Dũng', 'Đinh Ngọc', 0, 0, 0, 0, '2013-09-10 23:37:00', '2016-06-03 03:32:46', NULL, 'http://tuyenquang.dfa.vn', 'Viet Nam', '', 'c4e251af24513653af6bc33431eb95b1b3adc47f85f62e08fc24c375a21a8d13');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`user_id`, `group_id`) VALUES
(1, 1),
(9, 2),
(10, 3),
(11, 1),
(11, 6),
(13, 6),
(14, 2),
(15, 3),
(16, 2),
(17, 5),
(18, 3),
(19, 3),
(20, 3),
(21, 2),
(22, 2),
(23, 3),
(24, 3),
(25, 6),
(26, 2),
(27, 3),
(28, 6),
(29, 2),
(30, 3),
(31, 3),
(32, 3),
(33, 6),
(34, 2),
(35, 2),
(36, 3),
(37, 7),
(38, 2),
(39, 7),
(40, 3),
(41, 3),
(42, 2),
(43, 3),
(44, 3),
(45, 3),
(46, 2),
(47, 6),
(48, 3),
(49, 7),
(50, 2),
(51, 3),
(52, 5),
(53, 5),
(54, 3),
(55, 2),
(56, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_follow`
--

CREATE TABLE IF NOT EXISTS `user_follow` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `follow_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_place`
--

CREATE TABLE IF NOT EXISTS `user_place` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `place_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `form` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(5) NOT NULL DEFAULT 'on',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `widgets_refs`
--

CREATE TABLE IF NOT EXISTS `widgets_refs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `item_id` int(11) NOT NULL,
  `widget_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `position` tinyint(2) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(5) NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_post`
--
ALTER TABLE `category_post`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `cat_con_unique` (`category_id`,`post_id`), ADD KEY `category_content_content_id_foreign` (`post_id`), ADD KEY `category_id` (`category_id`), ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`c_id`), ADD KEY `user_one` (`user_one`), ADD KEY `user_two` (`user_two`);

--
-- Indexes for table `conversation_reply`
--
ALTER TABLE `conversation_reply`
  ADD PRIMARY KEY (`cr_id`), ADD KEY `user_id_fk` (`user_id_fk`), ADD KEY `c_id_fk` (`c_id_fk`);

--
-- Indexes for table `email_queue`
--
ALTER TABLE `email_queue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_service`
--
ALTER TABLE `email_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fbf_youtube_access_token`
--
ALTER TABLE `fbf_youtube_access_token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `medias`
--
ALTER TABLE `medias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_links`
--
ALTER TABLE `menu_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Indexes for table `notification_type`
--
ALTER TABLE `notification_type`
  ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Indexes for table `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id_3` (`id`), ADD KEY `id` (`id`), ADD KEY `user_id` (`user_id`), ADD KEY `category_id` (`category_id`), ADD KEY `media_id` (`media_id`);

--
-- Indexes for table `posts_position`
--
ALTER TABLE `posts_position`
  ADD PRIMARY KEY (`id`), ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `posts_versions`
--
ALTER TABLE `posts_versions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_tag`
--
ALTER TABLE `post_tag`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD KEY `post_id` (`post_id`), ADD KEY `tag_id` (`tag_id`);

--
-- Indexes for table `royalties`
--
ALTER TABLE `royalties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seos`
--
ALTER TABLE `seos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sidebars`
--
ALTER TABLE `sidebars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sidebars_refs`
--
ALTER TABLE `sidebars_refs`
  ADD PRIMARY KEY (`id`), ADD KEY `sidebar_id` (`sidebar_id`), ADD KEY `seoble_id` (`seoble_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tag_post`
--
ALTER TABLE `tag_post`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `throttle`
--
ALTER TABLE `throttle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`user_id`,`group_id`);

--
-- Indexes for table `user_follow`
--
ALTER TABLE `user_follow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_place`
--
ALTER TABLE `user_place`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Indexes for table `widgets_refs`
--
ALTER TABLE `widgets_refs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `category_post`
--
ALTER TABLE `category_post`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `conversation_reply`
--
ALTER TABLE `conversation_reply`
  MODIFY `cr_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `email_queue`
--
ALTER TABLE `email_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `email_service`
--
ALTER TABLE `email_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fbf_youtube_access_token`
--
ALTER TABLE `fbf_youtube_access_token`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `medias`
--
ALTER TABLE `medias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `menu_links`
--
ALTER TABLE `menu_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newsletters`
--
ALTER TABLE `newsletters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notification_type`
--
ALTER TABLE `notification_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `places`
--
ALTER TABLE `places`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts_position`
--
ALTER TABLE `posts_position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts_versions`
--
ALTER TABLE `posts_versions`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `post_tag`
--
ALTER TABLE `post_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `royalties`
--
ALTER TABLE `royalties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seos`
--
ALTER TABLE `seos`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT for table `sidebars`
--
ALTER TABLE `sidebars`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sidebars_refs`
--
ALTER TABLE `sidebars_refs`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tag_post`
--
ALTER TABLE `tag_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `throttle`
--
ALTER TABLE `throttle`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_follow`
--
ALTER TABLE `user_follow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_place`
--
ALTER TABLE `user_place`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `widgets_refs`
--
ALTER TABLE `widgets_refs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
